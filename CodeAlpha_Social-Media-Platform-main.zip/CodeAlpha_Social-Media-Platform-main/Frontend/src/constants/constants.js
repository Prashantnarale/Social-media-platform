const constants = function () {
	const api = "http://localhost:4000"
	const stripePublicKey = "pk_test_51H5TzhCWZOEqAHRfJufW6MCuM4SiV11LQSBJ25yyfWhOi0o8WMEDTGcZmjnkSNgS6qlw0HKoPHRpLuGB9sKMDCPT00xV8FLW8Q"

	return { api, stripePublicKey }
}

export default constants